package com.example.poxete.vinicularolheta.Classes;

import java.util.Date;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Parreiral {

    private int Codigo_Parreiral;
    private int Qtd_Vinhas;
    private int Area;
    private String NomePrp;
    private Date Data_Plantio;

    public Parreiral(int codigo_Parreiral, int qtd_Vinhas, int Area, String NomePrp, Date Data_Plantio) {
        this.Codigo_Parreiral = codigo_Parreiral;
        this.Qtd_Vinhas = qtd_Vinhas;
        this.Area = Area;
        this.NomePrp = NomePrp;
        this.Data_Plantio = Data_Plantio;
    }

    public int getCodigo_Parreiral() {
        return Codigo_Parreiral;
    }

    public void setCodigo_Parreiral(int codigo_Parreiral) {
        Codigo_Parreiral = codigo_Parreiral;
    }

    public int getQtd_Vinhas() {
        return Qtd_Vinhas;
    }

    public void setQtd_Vinhas(int qtd_Vinhas) {
        Qtd_Vinhas = qtd_Vinhas;
    }

    public int getArea() {
        return Area;
    }

    public void setArea(int area) {
        Area = area;
    }

    public String getNomePrp() {
        return NomePrp;
    }

    public void setNomePrp(String nomePrp) {
        NomePrp = nomePrp;
    }

    public Date getData_Plantio() {
        return Data_Plantio;
    }

    public void setData_Plantio(Date data_Plantio) {
        Data_Plantio = data_Plantio;
    }

}
