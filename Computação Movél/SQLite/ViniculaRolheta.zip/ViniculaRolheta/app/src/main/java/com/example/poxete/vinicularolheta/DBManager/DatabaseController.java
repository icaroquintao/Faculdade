package com.example.poxete.vinicularolheta.DBManager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by Poxete on 20/08/2017.
 */

public class DatabaseController {

    public static DatabaseController controller = null;

    public static DatabaseController getInstance(Context context) {
        if(controller == null) {
            controller = new DatabaseController(context);
        }
        return controller;
    }
    public static final String[] SCRIPT_DATABASE_INSERTION = new String[]{
            "insert into terroir\n" +
            "values('Bordeaux, França',61, 54,'arenoso', 60, 13);\n" +
            "\n" ,
            "insert into terroir\n" +
            "values('Amarante, Portugal',72, 701,'granito', 1200, 15);\n" +
            "\n" ,
            "insert into vinho (nomeVinho,classificacao,rotulo,codVinho)\n" +
            "values('Alvarinho','Varietal',1,1);\n" +
            "\n" ,
            "insert into vinho (nomeVinho,classificacao,rotulo,codVinho)\n" +
            "values('QG Espadeiro','Varietal',2,2);\n" +
            "\n" ,
            "insert into vinho (nomeVinho,classificacao,rotulo,codVinho)\n" +
            "values('Saint Germain','Assemblage',3,3);\n" +
            "\n" ,
            "insert into tipo_uva (nomeUva,regiao)\n" +
            "values('Alvarinho','Norte Portugal');\n" +
            "\n" ,
            "insert into tipo_uva (nomeUva,regiao)\n" +
            "values('Espadeiro','Sul Espanha');\n" +
            "\n" ,
            "INSERT INTO `propriedade` (`NomePropriedade`, `Endereco`, `Administrador`, `RegiaoTerroir`) \n" +
            "VALUES ('Bastos', 'Amarante_Porto', 'Dírio Catarino', 'Amarante, Portugal');\n" +
            "\n" ,
            "INSERT INTO `propriedade` (`NomePropriedade`, `Endereco`, `Administrador`, `RegiaoTerroir`) \n" +
            "VALUES ('Begles', 'Garone Bordeaux', 'Elaine Natalie', 'Bordeaux, França');\n" +
            "\n" ,
            "INSERT INTO `safra` (`anoSafra`, `nGarrafas`, `codVinho`,`CodSafra`) \n" +
            "VALUES ('2013', '200', '1','1');\n" +
            "\n" ,
            "INSERT INTO `safra` (`anoSafra`, `nGarrafas`, `codVinho`,`CodSafra`) \n" +
            "VALUES ('2014', '50', '2', '2');\n" +
            "\n" ,
            "INSERT INTO `safra` (`anoSafra`, `nGarrafas`, `codVinho`,`CodSafra`)\n" +
            " VALUES ('2014', '600', '3', '3');\n" +
            " \n" ,
            " INSERT INTO `safra` (`anoSafra`, `nGarrafas`, `codVinho`,`CodSafra`)\n" +
            " VALUES ('2014', '500', '1', '4');\n" +
            "\n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`)\n" +
            "VALUES ('Robert Parker', '90 de 0-100', '1');\n" +
            "\n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`)\n" +
            "VALUES ('Decanter', '4 de 5 estrelas', '1');\n" +
            " \n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`) \n" +
            "VALUES ('Jancis Robinson', '18 de 0-20', '1');\n" +
            "\n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`) \n" +
            "VALUES ('Wine Spectator', '93 de 50-100', '3');\n" +
            "\n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`) \n" +
            "VALUES ('Wine Spirits', '88 de 50-100', '3');\n" +
            "\n" ,
            "INSERT INTO `avaliacao` (`sistema`, `nota`, `codSafra`) \n" +
            "VALUES ('Wine Spirits', '78 de 50-100', '4');\n" +
            "\n" +
            "\n" ,
            "INSERT INTO `email` (`NomePropriedade`, `email`) \n" +
            "VALUES ('Bastos', 'bastosamarante@viniculas.com');\n" +
            "\n" ,
            "INSERT INTO `email` (`NomePropriedade`, `email`) \n" +
            "VALUES ('Begles', 'beglesbordeaux@viniculas.com');\n" +
            "\n" ,
            "INSERT INTO `telefone` (`NomePropriedade`, `telefone`) \n" +
            "VALUES ('Bastos', '+351 21 724 8510');\n" +
            "\n" ,
            "INSERT INTO `telefone` (`NomePropriedade`, `telefone`) \n" +
            "VALUES ('Begles', '+ 33 1 4411-1030');\n" +
            "\n" ,
            "INSERT INTO `parreiral` (`codParreiral`,`qntdVinhas`, `area`, `data_Plantio`, `NomePropriedade`) \n" +
            "VALUES ('1','800', '1200', '2005-05-24', 'Begles');\n" +
            "\n" ,
            "INSERT INTO `parreiral` (`codParreiral`,`qntdVinhas`, `area`, `data_Plantio`, `NomePropriedade`) \n" +
            "VALUES ('2', '750', '2005-03-13', 'Begles');\n" +
            "\n" ,
            "INSERT INTO `parreiral` (`codParreiral`,`qntdVinhas`, `area`, `data_Plantio`, `NomePropriedade`) \n" +
            "VALUES ('3','1000', '1500', '2006-01-21', 'Bastos');\n" +
            "\n" ,
            "INSERT INTO `parreiral` (`codParreiral`,`qntdVinhas`, `area`, `data_Plantio`, `NomePropriedade`) \n" +
            "VALUES ('4','1200', '1800', '2006-01-21', 'Bastos');\n" +
            "\n" ,
            "INSERT INTO `colheita` (`codColheita`,`preiodoMaturacao`, `tipoMaterial`, `codSafra`) \n" +
            "VALUES ('1','18', 'carvalho', '1');\n" +
            "\n" ,
            "INSERT INTO `colheita` (`codColheita`,`preiodoMaturacao`, `tipoMaterial`, `codSafra`) \n" +
            "VALUES ('2','26', 'carvalho', '2');\n" +
            "\n" ,
            "INSERT INTO `colheita` (`codColheita`,`preiodoMaturacao`, `tipoMaterial`, `codSafra`) \n" +
            "VALUES ('3','8', 'inox', '3');\n" +
            "\n" ,
            "INSERT INTO `colheita` (`codColheita`,`preiodoMaturacao`, `tipoMaterial`, `codSafra`) \n" +
            "VALUES ('4','8', 'inox', '4');\n" +
            "\n" ,
            "INSERT INTO `ocorrencia` (`codParreiral`, `codColheita`, `nomeUva`, `dataColheita`) \n" +
            "VALUES ('1', '1', 'Alvarinho', '2011-08-22');\n" +
            "\n" ,
            "INSERT INTO `ocorrencia` (`codParreiral`, `codColheita`, `nomeUva`, `dataColheita`) \n" +
            "VALUES ('2', '2', 'Espadeiro', '2011-03-12');\n" +
            "\n" ,
            "INSERT INTO `ocorrencia` (`codParreiral`, `codColheita`, `nomeUva`, `dataColheita`) \n" +
            "VALUES ('3', '3', 'Alvarinho', '2013-05-05');\n" +
            "\n" ,
            "INSERT INTO `ocorrencia` (`codParreiral`, `codColheita`, `nomeUva`, `dataColheita`) \n" +
            "VALUES ('4', '3', 'Espadeiro', '2013-05-05');\n" +
            "\n" ,
            "INSERT INTO `ocorrencia` (`codParreiral`, `codColheita`, `nomeUva`, `dataColheita`) \n" +
            "VALUES ('4', '4', 'Alvarinho', '2014-05-05');\n"};
    private static final String SCRIPT_DATABASE_DELETE = "DROP TABLE IF EXISTS aluno";

    private static final String[] SCRIPT_DATABASE_CREATE = new String[]{

                    "create table Terroir\n" +
                    "(RegiaoTerroir varchar(30),\n" +
                    "Umidade int not null,\n" +
                    "Altitude float not null,\n" +
                    "TipoSolo varchar(20) not null,\n" +
                    "IndicePluviometrico int not null,\n" +
                    "TempeteraturaMedia int not null,\n" +
                    "\n" +
                    "primary key (RegiaoTerroir)\n" +
                    "\n" +
                    ");",

                    "create table propriedade\n" +
                    "(NomePropriedade varchar(20) ,\n" +
                    "Endereco varchar(30) not null,\n" +
                    "Administrador varchar(30) not null,\n" +
                    "RegiaoTerroir varchar(30) not null,\n" +
                    "\n" +
                    "primary key (NomePropriedade),\n" +
                    "foreign key (RegiaoTerroir) references Terroir(RegiaoTerroir) on delete cascade on update cascade\n" +
                    ");\n",
                    "\n" +
                    "create table telefone\n" +
                    "(NomePropriedade varchar(20), \n" +
                    "telefone varchar(20) not null,\n" +
                    "\n" +
                    "primary key (NomePropriedade, telefone),\n" +
                    "foreign key (NomePropriedade) references propriedade(NomePropriedade) on delete cascade \n" +
                    "on update cascade\n" +
                    ");\n",
                    "\n" +
                    "\n" +
                    "create table email\n" +
                    "(NomePropriedade varchar(20), \n" +
                    "email varchar(30) not null,\n" +
                    "\n" +
                    "primary key (NomePropriedade, email),\n" +
                    "foreign key (NomePropriedade) references propriedade(NomePropriedade) on delete cascade on update cascade\n" +
                    ");\n" +
                    "\n",
                    "create table parreiral\n" +
                    "(codParreiral int primary key,\n" +
                    "qntdVinhas int not null,\n" +
                    "area float not null,\n" +
                    "data_Plantio varchar(10) not null,\n" +
                    "NomePropriedade varchar(20) not null,\n" +
                    "\n" +
                    "foreign key (NomePropriedade) references propriedade(NomePropriedade) on delete cascade\n" +
                    " on update cascade\n" +
                    ");\n" +
                    "\n" ,
                    "create table tipo_uva\n" +
                    "(nomeUva varchar(20) primary key,\n" +
                    "regiao varchar(25) not null\n" +
                    "); \n" +
                    "\n" ,
                    "create table vinho\n" +
                    "(nomeVinho varchar(30) unique not null,\n" +
                    "classificacao varchar(20) not null,\n" +
                    "codVinho int primary key ,\n" +
                    "rotulo blob \n" +
                    ");\n" +
                    "\n" ,
                    "create table safra\n" +
                    "(anoSafra int,\n" +
                    "nGarrafas int not null,\n" +
                    "CodSafra int not null unique,\n" +
                    "codVinho int,\n" +
                    "primary key (codVinho,anoSafra),\n" +
                    "foreign key (codVinho) references vinho(codVinho) on delete cascade on update cascade\n" +
                    ");\n" +
                    "\n" ,
                    "create table avaliacao\n" +
                    "(sistema varchar (20) not null,\n" +
                    "nota varchar(20),\n" +
                    "codSafra int not null,\n" +
                    "foreign key (codSafra) references safra (codSafra) on delete cascade on update cascade,\n" +
                    "primary key (sistema,codSafra)\n" +
                    ");\n" +
                    "\n" +
                    "\n" ,
                    "create table colheita\n" +
                    "(codColheita int ,\n" +
                    "preiodoMaturacao int not null,\n" +
                    "tipoMaterial varchar (20) not null,\n" +
                    "codSafra int not null,\n" +
                    "primary key (codColheita),\n" +
                    "foreign key (codSafra) references safra(codSafra) on delete cascade on update cascade\n" +
                    ");\n" +
                    "\n" ,
                    "create table ocorrencia\n" +
                    "(codParreiral int, \n" +
                    "codColheita int,\n" +
                    "nomeUva varchar(20) not null,\n" +
                    "dataColheita varchar(10) not null,\n" +
                    "\n" +
                    "foreign key (codParreiral) references parreiral(codParreiral) on delete cascade on update cascade,\n" +
                    "foreign key (codColheita) references colheita(codColheita) on delete cascade on update cascade,\n" +
                    "foreign key (nomeUva) references tipo_uva(nomeUva) on delete cascade on update cascade,\n" +
                    "primary key (CodParreiral, codColheita));\n"
    };

    private static final String NOME_BD = "vinicola";

    private static final int VERSAO_BD = 1;

    private SQLiteHelper dbHelper;

    public SQLiteDatabase db;

    //    public DatabaseController(Context context) {
    private DatabaseController(Context context) {
        dbHelper = new SQLiteHelper(context, NOME_BD, null, VERSAO_BD, SCRIPT_DATABASE_CREATE, SCRIPT_DATABASE_DELETE);
        db = dbHelper.getWritableDatabase();

    }

//    public long salvar(Aluno aluno) {
//        long id = aluno.getId();
//        if(id != 0)
//            atualizar(aluno);
//        else
//            id = inserir(aluno);
//        return id;
//    }

    public long inserir(/*Aluno aluno*/) {
        ContentValues values = new ContentValues();
        //values.put("matricula", aluno.getMatricula());
        //values.put("nome", aluno.getNome());
        //values.put("curso", aluno.getCurso());
        //values.put("periodo", aluno.getPeriodo());
        //values.put("coeficiente", aluno.getCoeficiente());
        long id = db.insert("aluno", "", values);
        Log.i("CSI489", "Inseriu o registro " + id);
        return id;
//        String sql = "insert into aluno(matricula, nome, curso, periodo, coeficiente) " +
//                "values(" + aluno.getMatricula() + ", '" + aluno.getNome() + "', '" +
//                aluno.getCurso() + "', " + aluno.getPeriodo() + ", " + aluno.getCoeficiente() + ");";
//        db.execSQL(sql);
//        return 1;
    }

    public int atualizar(/*Aluno aluno*/) {
//        ContentValues values = new ContentValues();
//        values.put("matricula", aluno.getMatricula());
//        values.put("nome", aluno.getNome());
//        values.put("curso", aluno.getCurso());
//        values.put("periodo", aluno.getPeriodo());
//        values.put("coeficiente", aluno.getCoeficiente());
//        String _id = String.valueOf(aluno.getId());
//        String where = "_id=?";
//        String[] whereArgs = new String[] {_id};
//        int count = db.update("aluno", values, where, whereArgs);
//        Log.i("CSI489", "Atualizou " + count + " registros.");
//        return count;
        //String sql = "update aluno set matricula = " + aluno.getMatricula() + ", nome = '" +aluno.getNome() +
        //        "', curso = '" + aluno.getCurso()+ "', periodo = " + aluno.getPeriodo() +
        //        ", coeficiente = " + aluno.getCoeficiente() + " where _id = " + aluno.getId() + ";";
        //db.execSQL(sql);
        return 1;
    }

    public int deletar(long id) {
//        String _id = String.valueOf(id);
//        String where = "_id=?";
//        String[] whereArgs = new String[] {_id};
//        int count = db.delete("aluno", where, whereArgs);
//        Log.i("CSI489", "Deletou " + count + " registros.");
//        return count;
        String sql = "delete from aluno where _id = " + id;
        db.execSQL(sql);
        return 1;
    }

    public ArrayList<String> buscarSafraSpinner(){
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "safra", //from
                new String[]{"anoSafra","CodSafra"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            int anoSafra,codSafra;
            anoSafra = c.getInt(0);
            codSafra = c.getInt(1);
            retorno.add(String.format("%d: %d",codSafra,anoSafra));
        }while (c.moveToNext());

        return retorno;
    }
    public ArrayList<String> buscarRegiaoTerroirSpinner(){
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "Terroir", //from
                new String[]{"RegiaoTerroir"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String regiao;
            regiao = c.getString(0);
            retorno.add(regiao);
        }while (c.moveToNext());

        return retorno;
    }
    public ArrayList<String> buscarTipoDeUva() {
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "tipo_uva", //from
                new String[]{"nomeUva"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String nomeUva;
            nomeUva = c.getString(0);
            retorno.add(nomeUva);
        }while (c.moveToNext());

        return retorno;
    }
    public ArrayList<String> buscarPropriedades() {
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "propriedade", //from
                new String[]{"NomePropriedade"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String nome;
            nome = c.getString(0);
            retorno.add(nome);
        }while (c.moveToNext());

        return retorno;
    }

    public ArrayList<String> buscarVinhoSpinner() {
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "vinho", //from
                new String[]{"nomeVinho","codVinho"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String nome,codigo;
            nome = c.getString(0);
            codigo = c.getString(1);
            retorno.add(codigo + ":" + nome);
        }while (c.moveToNext());

        return retorno;
    }
    public ArrayList<String> buscarParreiralSpinner() {
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "parreiral", //from
                new String[]{"codParreiral","data_Plantio"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String codigo,dataplantio;
            codigo = c.getString(0);
            dataplantio = c.getString(1);
            retorno.add(codigo + ": " + dataplantio);
        }while (c.moveToNext());

        return retorno;
    }
    public ArrayList<String> buscarVinhos() {
        ArrayList<String> retorno = new ArrayList<>();

        Cursor c = db.query(
                "vinho", //from
                new String[]{"nomeVinho","classificacao","codVinho"}, //select
                null,//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        do{
            String codigo,classificacao,nome;
            nome = c.getString(0);
            classificacao = c.getString(1);
            codigo = c.getString(2);
            retorno.add(nome + " - " + classificacao + " - " + codigo);
        }while (c.moveToNext());

        return retorno;
    }
    public String safrasDeUmVinho(String nomeVinho){
        String retorno = "";

        Cursor c = db.query(
                "safra S, vinho V, avaliacao A", //from
                new String[]{"S.anoSafra","V.nomeVinho","A.sistema","A.nota"}, //select
                "S.codVinho = V.codVinho and V.nomeVinho = '"+nomeVinho+"' and S.CodSafra = A.codSafra",//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                "A.sistema",//order by
                null); //limit
        c.moveToFirst();
        try{do{
            int anoSafra;
            String nVinho;
            String sistema;
            String nota;
            anoSafra = c.getInt(0);
            nVinho = c.getString(1);
            sistema = c.getString(2);
            nota = c.getString(3);
            retorno = retorno + String.format("Safra de %d\nSistema de avaliação: %s\nNota: %s\n\n\n",anoSafra,sistema,nota);
        }while (c.moveToNext());}catch(Exception e){}

        return retorno;

    }

    public String PropriedadesEmUmAno(int ano){
        String retorno = "";
        Cursor c = db.query(
                "propriedade P, parreiral R, ocorrencia O, safra S, colheita C", //from
                new String[]{"P.NomePropriedade","sum(S.nGarrafas)","S.anoSafra"}, //select
                "P.NomePropriedade = R.NomePropriedade and R.codParreiral = O.codParreiral and O.codColheita = C.codColheita \n" +
                        "and C.codSafra = S.CodSafra and S.anoSafra="+ano+"\n",//where
                null, //argumentos da seleção
                "P.NomePropriedade", //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        try{do{
            String nomePropriedade;
            int soma;
            int anoSafra;
            nomePropriedade = c.getString(0);
            soma = c.getInt(1);
            anoSafra = c.getInt(2);
            retorno = retorno + String.format("Nome da propriedade: %s\nProdução total: %d\nAno: %d\n\n\n",nomePropriedade,soma,anoSafra);
        }while (c.moveToNext());}catch(Exception e){}

        return retorno;
    }

    public String Tiposdeuvapropriedade (String nome){
        String retorno = "";
        Cursor c = db.query(
                "propriedade P, parreiral R, ocorrencia O, tipo_uva U", //from
                new String[]{"distinct P.NomePropriedade","U.nomeUva"}, //select
                "P.NomePropriedade = R.NomePropriedade and R.codParreiral = O.codParreiral and\n" +
                        "O.nomeUva = U.nomeUva and P.NomePropriedade = '"+nome+"'\n",//where
                null, //argumentos da seleção
                null, //group by
                null, //having
                null,//order by
                null); //limit
        c.moveToFirst();
        try{do{
            String nomePropriedade;
            String nomeUva;

            nomePropriedade = c.getString(0);
            nomeUva = c.getString(1);

            retorno = retorno + String.format("\n%s\n",nomeUva);
        }while (c.moveToNext());}catch(Exception e){}

        return retorno;
    }

    public String anomaisprodutivo(){
        String retorno = "";
        Cursor c = db.query(
                "propriedade P, parreiral R, ocorrencia O, safra S, colheita C", //from
                new String[]{"O.nomeUva","sum(S.nGarrafas)","S.anoSafra"}, //select
                "P.NomePropriedade = R.NomePropriedade and R.codParreiral = O.codParreiral and O. codColheita = C.codColheita \n" +
                        "and C.codSafra = S.CodSafra\n",//where
                null, //argumentos da seleção
                "S.anoSafra, O.nomeUva", //group by
                null, //having
                "O.nomeUva, S.nGarrafas desc",//order by
                null); //limit
        c.moveToFirst();
        try{do{
            String nomeUva;
            int soma;
            int anoSafra;

            nomeUva = c.getString(0);
            soma = c.getInt(1);
            anoSafra = c.getInt(2);

            retorno = retorno + String.format("%s %d - %d\n\n",nomeUva,anoSafra,soma);
        }while (c.moveToNext());}catch(Exception e){}

        return retorno;
    }
    /*public Aluno buscarPorId(long id) {
        //select * from aluno where _id=id
        Cursor c = db.query(
                "aluno", //from
                new String[]{"_id", "matricula", "nome", "curso", "periodo", "coeficiente"}, //select
                "_id=" + id, //where
                null, //argumentos da seleção (usar ?s em where e passar valores aqui)
                null, //group by
                null, //having
                null, //orderby
                null); //limit
        if(c.getCount() > 0) {
            c.moveToFirst();
            long _id = c.getLong(0);
            int matricula = c.getInt(1);
            String nome = c.getString(2);
            String curso = c.getString(3);
            int periodo = c.getInt(4);
            double coeficiente = c.getDouble(5);
            return new Aluno(_id, matricula, nome, curso, periodo, coeficiente);
        }
        return null;
    }*/

    public Cursor getCursor() throws SQLException {
        //select * from aluno
        return db.query("aluno",
                new String[]{"_id", "matricula", "nome", "curso", "periodo", "coeficiente"}, //select
                null,
                null,
                null,
                null,
                null,
                null
        );
    }

    /*public ArrayList<Aluno> listarAlunos() {
        Cursor c = db.query(
                "aluno", //from
                new String[]{"_id", "matricula", "nome", "curso", "periodo", "coeficiente"}, //select
                null, //where
                null, //argumentos da seleção (usar ?s em where e passar valores aqui)
                null, //group by
                null, //having
                null, //orderby
                null); //limit
        ArrayList<Aluno> alunos = new ArrayList<Aluno>();
        if(c.moveToFirst()) {
            do {
                long id = c.getLong(0);
                int matricula = c.getInt(1);
                String nome = c.getString(2);
                String curso = c.getString(3);
                int periodo = c.getInt(4);
                double coeficiente = c.getDouble(5);
                alunos.add(new Aluno(id, matricula, nome, curso, periodo, coeficiente));
            } while(c.moveToNext());
        }
        return alunos;
    }*/

    public void fechar() {
        if(db != null) {
            db.close();
        }
    }



}
