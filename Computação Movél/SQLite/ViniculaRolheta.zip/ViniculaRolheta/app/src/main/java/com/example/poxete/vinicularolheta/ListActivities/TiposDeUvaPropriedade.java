package com.example.poxete.vinicularolheta.ListActivities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class TiposDeUvaPropriedade extends AppCompatActivity {
    ArrayList<String> PROPRIEDADES;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tipos_de_uva_propriedade);
        setTitle("Selecione uma propriedade");
        inicializaSpinnerPropriedade();
    }
    private void inicializaSpinnerPropriedade() {
        PROPRIEDADES = carregaPropriedades();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,PROPRIEDADES);

        Spinner spinner = (Spinner) findViewById(R.id.spinnertipodeuvapropriedade);
        spinner.setAdapter(adapter);
    }

    private ArrayList<String> carregaPropriedades() {
        return DatabaseController.getInstance(this).buscarPropriedades();
    }
    void att(View v){
        Spinner spinner = (Spinner) findViewById(R.id.spinnertipodeuvapropriedade);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Propriedade não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }

        String exibir = DatabaseController.getInstance(this).Tiposdeuvapropriedade(PROPRIEDADES.get(spinner.getSelectedItemPosition()));
        TextView tv = (TextView) findViewById(R.id.textViewtiposdeuvapropriedade);
        if(exibir.trim().isEmpty())
            exibir = "Sem dados a exibir sobre essa propriedade.";
        tv.setText(exibir);



    }
}
