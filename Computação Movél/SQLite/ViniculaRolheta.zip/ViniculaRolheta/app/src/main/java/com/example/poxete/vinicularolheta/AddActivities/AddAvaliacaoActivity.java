package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class AddAvaliacaoActivity extends AppCompatActivity {
    private ArrayList<String> SAFRAS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_avaliacao);
        inicializaSpinnerSafra();
    }
    ArrayList<String> carregaSafras(){

        return DatabaseController.getInstance(this).buscarSafraSpinner();
    }

    void inicializaSpinnerSafra(){
        SAFRAS = carregaSafras();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,SAFRAS);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAvaliacaoSafra);
        spinner.setAdapter(adapter);

    }

    void confirm (View v){
        EditText sistema = (EditText) findViewById(R.id.editTextSistemaAvaliacao);
        String texto = sistema.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Sistema não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            sistema.requestFocus();
            return;
        }

        EditText nota = (EditText) findViewById(R.id.editTextNotaAvaliacao);
        texto = nota.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Nota não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            nota.requestFocus();
            return;
        }
        Spinner spinner = (Spinner) findViewById(R.id.spinnerAvaliacaoSafra);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Safra relacionada não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }

        adicionarAvaliacao(sistema.getText().toString(),nota.getText().toString(),Integer.parseInt(SAFRAS.get(spinner.getSelectedItemPosition()).split(":")[0]));
    }

    private void adicionarAvaliacao(String sistema,String nota,int codSafra) {
        try{
        ContentValues values = new ContentValues();
        values.put("sistema", sistema);
        values.put("nota", nota);
        values.put("codSafra", codSafra);
        DatabaseController.getInstance(this).db.insert("avaliacao", "", values);}catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
    }
}
