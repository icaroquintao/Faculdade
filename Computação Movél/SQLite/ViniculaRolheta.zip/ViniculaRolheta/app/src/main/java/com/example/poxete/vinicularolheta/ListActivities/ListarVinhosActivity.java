package com.example.poxete.vinicularolheta.ListActivities;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class ListarVinhosActivity extends ListActivity{
    ArrayList<String> VINHOS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        atualizaListViewVinhos();


    }


    private void atualizaListViewVinhos() {
        VINHOS = carregaVinhos();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,VINHOS);
        setListAdapter(adapter);

    }

    private ArrayList<String> carregaVinhos() {
        return DatabaseController.getInstance(this).buscarVinhos();
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

 //       Intent it = new Intent(this,SafrasDeUmVinho.class);
   //     it.putExtra("Vinho",VINHOS.get(position));

    }
}
