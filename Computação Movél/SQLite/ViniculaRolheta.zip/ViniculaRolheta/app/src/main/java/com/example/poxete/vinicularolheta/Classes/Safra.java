package com.example.poxete.vinicularolheta.Classes;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Safra {

    private int Ano_Safra;
    private int N_Garrafas;
    private int Cod_Safra;

    public Safra(int Ano_Safra, int N_Garrafas, int Cod_Safra){
        this.Ano_Safra = Ano_Safra;
        this.Cod_Safra = Cod_Safra;
        this.N_Garrafas = N_Garrafas;
    }

    public int getAno_Safra() {
        return Ano_Safra;
    }

    public void setAno_Safra(int ano_Safra) {
        Ano_Safra = ano_Safra;
    }

    public int getN_Garrafas() {
        return N_Garrafas;
    }

    public void setN_Garrafas(int n_Garrafas) {
        N_Garrafas = n_Garrafas;
    }

    public int getCod_Safra() {
        return Cod_Safra;
    }

    public void setCod_Safra(int cod_Safra) {
        Cod_Safra = cod_Safra;
    }

    public String simpleToString(){
        return String.format("%d: %d",Cod_Safra,Ano_Safra);
    }
}
