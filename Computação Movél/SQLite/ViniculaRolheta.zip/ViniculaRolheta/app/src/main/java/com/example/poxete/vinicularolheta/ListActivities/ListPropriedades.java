package com.example.poxete.vinicularolheta.ListActivities;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

public class ListPropriedades extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_propriedades);
        setTitle("Digite um ano: ");
    }

    void att(View v){
        EditText ano = (EditText) findViewById(R.id.editTextAnoBuscaPropriedade);
        String texto = ano.getText().toString();
        if(texto.trim().isEmpty()){
            Toast.makeText(this,"O campo ano não pode estar vazio.",Toast.LENGTH_SHORT).show();
            ano.requestFocus();
            return;
        }
        int anobusca = Integer.parseInt(texto);
        String retorno = DatabaseController.getInstance(this).PropriedadesEmUmAno(anobusca);

        if (retorno.trim().isEmpty())
            retorno = "Sem dados sobre esse ano";
        TextView tv = (TextView) findViewById(R.id.textViewProducaoPropriedadesAno);
        tv.setText(retorno);
    }
}
