package com.example.poxete.vinicularolheta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.AddActivities.AddPropriedadeActivity;
import com.example.poxete.vinicularolheta.DBManager.DatabaseController;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Vinícula Rolheta");
        //deleteDatabase("vinicola");

    }

    public void addActivity(View v){
        Intent it = new Intent(this, AddActivity.class);
        startActivity(it);
    }

    public void exibirRelatorios(View v){
        Intent it = new Intent(this, ListMenu.class);
        startActivity(it);
    }

    public void reset(View v){
        deleteDatabase("vinicola");
        Toast.makeText(this,"Banco deletado.",Toast.LENGTH_SHORT).show();
        for(int i=0; i< DatabaseController.getInstance(this).SCRIPT_DATABASE_INSERTION.length;i++)
          try{DatabaseController.getInstance(this).db.execSQL(DatabaseController.getInstance(this).SCRIPT_DATABASE_INSERTION[i]);}catch(Exception e){e.printStackTrace();}
    }
}
