package com.example.poxete.vinicularolheta.Classes;

import java.util.Date;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Ocorrencia {
    private int Codigo_Parreiral;
    private int Codigo_Colheita;
    private String Nome_Uva;
    public Date Data_Colheita;

    public Ocorrencia(int Codigo_Parreiral, int Codigo_Colheita, String Nome_Uva, Date Data_Colheita ){
        this.Codigo_Colheita = Codigo_Colheita;
        this.Codigo_Parreiral = Codigo_Parreiral;
        this.Nome_Uva = Nome_Uva;
        this.Data_Colheita = Data_Colheita;
    }

    public int getCodigo_Parreiral() {
        return Codigo_Parreiral;
    }

    public void setCodigo_Parreiral(int codigo_Parreiral) {
        Codigo_Parreiral = codigo_Parreiral;
    }

    public int getCodigo_Colheita() {
        return Codigo_Colheita;
    }

    public void setCodigo_Colheita(int codigo_Colheita) {
        Codigo_Colheita = codigo_Colheita;
    }

    public String getNome_Uva() {
        return Nome_Uva;
    }

    public void setNome_Uva(String nome_Uva) {
        Nome_Uva = nome_Uva;
    }

    public Date getData_Colheita() {
        return Data_Colheita;
    }

    public void setData_Colheita(Date data_Colheita) {
        Data_Colheita = data_Colheita;
    }


}
