package com.example.poxete.vinicularolheta.Classes;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Tipo_de_uva {
    private String Nome_Uva;
    private String Regiao;

    public Tipo_de_uva(String Nome_Uva, String Regiao) {
        this.Nome_Uva = Nome_Uva;
        this.Regiao = Regiao;
    }

    public String getNome_Uva() {
        return Nome_Uva;
    }

    public void setNome_Uva(String nome_Uva) {
        Nome_Uva = nome_Uva;
    }

    public String getRegiao() {
        return Regiao;
    }

    public void setRegiao(String regiao) {
        Regiao = regiao;
    }
}
