package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddColheitaActivity extends AppCompatActivity {
    private ArrayList<String> SAFRAS;
    private ArrayList<String> PARREIRAIS;
    private ArrayList<String> TIPOSDEUVA;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_colheita);
        setTitle("Adicionar Nova Colheita");
        inicializaSpinnerSafra();
        inicializaSpinnerParreiral();
        inicializaSpinnerTiposDeUva();
    }

    private void inicializaSpinnerTiposDeUva() {
        TIPOSDEUVA = carregaTiposDeUva();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,TIPOSDEUVA);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerTipoDeUva);
        spinner.setAdapter(adapter);
    }

    private ArrayList<String> carregaTiposDeUva() {
        return DatabaseController.getInstance(this).buscarTipoDeUva();
    }

    private void inicializaSpinnerParreiral() {
        PARREIRAIS = carregaParreirais();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,PARREIRAIS);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerParreiral);
        spinner.setAdapter(adapter);
    }

    private ArrayList<String> carregaParreirais() {
        return DatabaseController.getInstance(this).buscarParreiralSpinner();
    }

    ArrayList<String> carregaSafras(){

        return DatabaseController.getInstance(this).buscarSafraSpinner();
    }

    void inicializaSpinnerSafra(){
        SAFRAS = carregaSafras();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,SAFRAS);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddColheita);
        spinner.setAdapter(adapter);

    }
    public void confirm (View v){
        EditText codigoColheita = (EditText) findViewById(R.id.editTextCodigoColheita);
        String texto = codigoColheita.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Código da colheita não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            codigoColheita.requestFocus();
            return;
        }

        EditText periodoMaturacao = (EditText) findViewById(R.id.editTextPeriodoMaturacao);
        texto = periodoMaturacao.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Período de Maturação não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            periodoMaturacao.requestFocus();
            return;
        }

        EditText material = (EditText) findViewById(R.id.editTextMaterialMaturacao);
        texto = material.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Material utilizado na maturação não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            material.requestFocus();
            return;
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddColheita);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Safra relacionada não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }
        Spinner spinnerparreiral = (Spinner) findViewById(R.id.spinnerParreiral);
        if(spinnerparreiral.getSelectedItem() == null)
        {
            Toast.makeText(this,"Parreiral não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinnerparreiral.requestFocus();
            return;
        }
        Spinner spinnertipodeuva = (Spinner) findViewById(R.id.spinnerTipoDeUva);
        if(spinnertipodeuva.getSelectedItem() == null)
        {
            Toast.makeText(this,"Tipo de uva não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinnertipodeuva.requestFocus();
            return;
        }

        DatePicker date = (DatePicker) findViewById(R.id.datePickerDataColheita);
        int dia = date.getDayOfMonth();
        int mes = date.getMonth();
        int ano = date.getYear();
        ano-=1900;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        adicionaColheita(Integer.parseInt(codigoColheita.getText().toString()), Integer.parseInt(periodoMaturacao.getText().toString()), material.getText().toString(), Integer.parseInt(SAFRAS.get(spinner.getSelectedItemPosition()).split(":")[0]),
                Integer.parseInt(PARREIRAIS.get(spinnerparreiral.getSelectedItemPosition()).split(":")[0]),
                TIPOSDEUVA.get(spinnertipodeuva.getSelectedItemPosition()),
                sdf.format(new Date(ano,mes,dia)));

    }

    void adicionaColheita(int codigoColheita, int periodoMaturacao, String material,int codigoSafra,int codParreiral,String nomeUva,String datacolheita){//data colheita
        try {
            ContentValues values = new ContentValues();
            values.put("codColheita", codigoColheita);
            values.put("preiodoMaturacao", periodoMaturacao);
            values.put("tipoMaterial", material);
            values.put("codSafra", codigoSafra);

            DatabaseController.getInstance(this).db.insert("colheita", "", values);

            ContentValues values2 = new ContentValues();
            values2.put("codParreiral", codParreiral);
            values2.put("codColheita", codigoColheita);
            values2.put("nomeUva", nomeUva);
            values2.put("dataColheita", datacolheita);

            DatabaseController.getInstance(this).db.insert("ocorrencia", "", values2);
        }catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}
