package com.example.poxete.vinicularolheta.DBManager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Poxete on 20/08/2017.
 */

public class SQLiteHelper extends SQLiteOpenHelper {

    private String[] scriptSQLCreate;
    private String scriptSQLDelete;

    public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                        int version, String[] scriptSQLCreate, String scriptSQLDelete) {
        super(context, name, factory, version);
        this.scriptSQLCreate = scriptSQLCreate;
        this.scriptSQLDelete = scriptSQLDelete;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("CSI489", "Criando Banco de Dados");
        for(int i = 0; i < scriptSQLCreate.length; ++i) {
            db.execSQL(scriptSQLCreate[i]);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i("CSI489", "Atualizando da versão " + oldVersion + " para " + newVersion
                + ". Todos os registros serão deletados.");
        db.execSQL(scriptSQLDelete);
        //Cria banco de dados novamente
        onCreate(db);
    }
}
