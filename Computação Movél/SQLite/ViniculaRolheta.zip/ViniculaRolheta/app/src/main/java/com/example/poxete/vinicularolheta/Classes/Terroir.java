package com.example.poxete.vinicularolheta.Classes;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Terroir {

    private String Regiao_Terroir;
    private String Umidade;
    private String Altitude;
    private String Tipo_de_Solo;
    private String Indice_Pluviometrico;
    private String Temperatura_Media;

    public Terroir(String Regiao_Terroir, String Umidade, String Altitude, String Tipo_de_Solo, String Indice_Pluviometrico, String Temperatura_Media) {
        this.Regiao_Terroir = Regiao_Terroir;
        this.Umidade = Umidade;
        this.Altitude = Altitude;
        this.Tipo_de_Solo = Tipo_de_Solo;
        this.Indice_Pluviometrico = Indice_Pluviometrico;
        this.Temperatura_Media = Temperatura_Media;
    }

    public String getRegiao_Terroir() {
        return Regiao_Terroir;
    }

    public void setRegiao_Terroir(String regiao_Terroir) {
        Regiao_Terroir = regiao_Terroir;
    }

    public String getUmidade() {
        return Umidade;
    }

    public void setUmidade(String umidade) {
        Umidade = umidade;
    }

    public String getAltitude() {
        return Altitude;
    }

    public void setAltitude(String altitude) {
        Altitude = altitude;
    }

    public String getTipo_de_Solo() {
        return Tipo_de_Solo;
    }

    public void setTipo_de_Solo(String tipo_de_Solo) {
        Tipo_de_Solo = tipo_de_Solo;
    }

    public String getIndice_Pluviometrico() {
        return Indice_Pluviometrico;
    }

    public void setIndice_Pluviometrico(String indice_Pluviometrico) {
        Indice_Pluviometrico = indice_Pluviometrico;
    }

    public String getTemperatura_Media() {
        return Temperatura_Media;
    }

    public void setTemperatura_Media(String temperatura_Media) {
        Temperatura_Media = temperatura_Media;
    }



}
