package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

public class AddTipoDeUvaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tipo_de_uva);
        setTitle("Adicionar Novo Tipo De Uva");
    }

    void confirm (View v){
        EditText nometipouva = (EditText) findViewById(R.id.editTextNomeTipoDeUva);
        String texto = nometipouva.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Nome do tipo de uva não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            nometipouva.requestFocus();
            return;
        }

        EditText regiaoTipoUva = (EditText) findViewById(R.id.editTextRegiaoTipoDeUva);
        texto = regiaoTipoUva.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Região do tipo de uva não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            regiaoTipoUva.requestFocus();
            return;
        }

        adicionarTipoDeUva(nometipouva.getText().toString(), regiaoTipoUva.getText().toString());
    }

    private void adicionarTipoDeUva(String nomeUva, String regiao) {//table tipo_uva
        try{ContentValues values = new ContentValues();
        values.put("nomeUva", nomeUva);
        values.put("regiao", regiao);

        DatabaseController.getInstance(this).db.insert("tipo_uva","",values);}catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);

    }
}
