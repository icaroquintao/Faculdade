package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

public class AddTerroirActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_terroir);
        setTitle("Adicionar Novo Terroir");
    }

    void confirm(View v){
        EditText regiaoterroir = (EditText) findViewById(R.id.editTextRegiao);
        String texto = regiaoterroir.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Região não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            regiaoterroir.requestFocus();
            return;
        }

        EditText umidade = (EditText) findViewById(R.id.editTextUmidade);
         texto = umidade.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Umidade não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            umidade.requestFocus();
            return;
        }

        EditText altura = (EditText) findViewById(R.id.editTextAltura);
        texto = altura.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Altitude não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            altura.requestFocus();
            return;
        }

        EditText tipoSolo = (EditText) findViewById(R.id.editTextTipoSolo);
        texto = tipoSolo.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Tipo de solo não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            tipoSolo.requestFocus();
            return;
        }

        EditText indice = (EditText) findViewById(R.id.editTextIndicePluviometrico);
        texto = indice.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Índice Pluviométrico não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            indice.requestFocus();
            return;
        }

        EditText tempMedia = (EditText) findViewById(R.id.editTextTemperaturaMedia);
        texto = tempMedia.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Temperatura média não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            tempMedia.requestFocus();
            return;
        }

        adicionaTerroir(regiaoterroir.getText().toString(),
                        Integer.parseInt(umidade.getText().toString()),
                        Float.parseFloat(altura.getText().toString()),
                        tipoSolo.getText().toString(),
                        Integer.parseInt(indice.getText().toString()),
                        Integer.parseInt(tempMedia.getText().toString()));
    }

    void adicionaTerroir (String regiao, int umidade, float altitude,String tipoSolo, int indice,int tempMedia){
       try{ ContentValues values = new ContentValues();
        values.put("RegiaoTerroir", regiao);
        values.put("Umidade", umidade);
        values.put("Altitude", altitude);
        values.put("TipoSolo", tipoSolo);
        values.put("IndicePluviometrico", indice);
        values.put("TempeteraturaMedia", tempMedia);

        DatabaseController.getInstance(this).db.insert("Terroir","",values);}catch(Exception e){
           Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
       }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}
