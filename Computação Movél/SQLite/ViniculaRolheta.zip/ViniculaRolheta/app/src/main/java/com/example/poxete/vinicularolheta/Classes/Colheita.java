package com.example.poxete.vinicularolheta.Classes;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Colheita {
    private int Codigo_Colheita;
    private String Periodo_de_Maturação;
    private String Material_Maturação;
    public int Codigo_Safra;

    public Colheita(int codColheita, String periodMatu, String materialMat, int codSafra){
        this.Codigo_Colheita = codColheita;
        this.Codigo_Safra = codSafra;
        this.Material_Maturação = materialMat;
        this.Periodo_de_Maturação = periodMatu;
    }

    public void mudaPeriodoMatura(String x){
        this.Periodo_de_Maturação = x;
    }
    //nao achei necessario mais operações de mundanças pois os outros atributos dificilmente seriam mudados
    public int getCodigoColheita() {
        return Codigo_Colheita;
    }
    public void setCodigoColheita(int codigoColheita) {
        this.Codigo_Colheita = codigoColheita;
    }
    public String getPeriodoMaturação() {
        return Periodo_de_Maturação;
    }
    public void setPeriodoMaturação(String periodoMaturação) {
        this.Periodo_de_Maturação = periodoMaturação;
    }
    public String getMaterialMaturação() {
        return Material_Maturação;
    }
    public void setMaterialMaturação(String materialMaturação) {
        this.Material_Maturação = materialMaturação;
    }
    public int getCodigoSafra() {
        return Codigo_Safra;
    }
    public void setCodigoSafra(int codigoSafra) {
        this.Codigo_Safra = codigoSafra;
    }

}
