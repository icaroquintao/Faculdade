package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class AddSafraActivity extends AppCompatActivity {
    ArrayList<String> VINHOS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_safra);
        setTitle("Adicionar nova Safra");
        inicializaSpinnerVinhos();
    }

    private void inicializaSpinnerVinhos() {
        VINHOS = carregaVinhos();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,VINHOS);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerVinhoSafra);
        spinner.setAdapter(adapter);
    }

    private ArrayList<String> carregaVinhos() {
        return DatabaseController.getInstance(this).buscarVinhoSpinner();
    }

    void confirm (View v){
        EditText anoSafra = (EditText) findViewById(R.id.editTextAnoDaSafra);
        String texto = anoSafra.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Ano da safra não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            anoSafra.requestFocus();
            return;
        }

        EditText numerogarrafas = (EditText) findViewById(R.id.editTextNumeroDeGarrafas);
        texto = numerogarrafas.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Número de garrafas não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            numerogarrafas.requestFocus();
            return;
        }

        EditText codigoSafra = (EditText) findViewById(R.id.editTextCodigoSafra);
        texto = codigoSafra.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Código da safra não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            codigoSafra.requestFocus();
            return;
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinnerVinhoSafra);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Vinho que será originado não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }

        adicionaSafra(Integer.parseInt(anoSafra.getText().toString()),
                      Integer.parseInt(numerogarrafas.getText().toString()),
                      Integer.parseInt(codigoSafra.getText().toString()),
                      Integer.parseInt(VINHOS.get(spinner.getSelectedItemPosition()).split(":")[0]));


    }

    private void adicionaSafra(int anoSafra, int nGarrafas,int CodSafra,int codVinho) {//table safra
       try{ ContentValues values = new ContentValues();

        values.put("anoSafra", anoSafra);
        values.put("nGarrafas", nGarrafas);
        values.put("CodSafra", CodSafra);
        values.put("codVinho", codVinho);

        DatabaseController.getInstance(this).db.insert("safra","",values);}catch(Exception e){
           Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
       }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);

    }
}
