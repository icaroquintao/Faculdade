package com.example.poxete.vinicularolheta.Classes;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Avaliacao {
    private String Sistema;
    private int Nota;
    public int Codigo_Safra;

    public Avaliacao(int Nota, int Codigo_Safra, String Sistema){
        this.Codigo_Safra = Codigo_Safra;
        this.Nota = Nota;
        this.Sistema = Sistema;
    }

    public void Muda_nota(int x){
        this.Nota = x;
    }

    public String getSistema() {
        return Sistema;
    }

    public void setSistema(String sistema) {
        Sistema = sistema;
    }

    public int getNota() {
        return Nota;
    }

    public void setNota(int nota) {
        Nota = nota;
    }

    public int getCodigo_Safra() {
        return Codigo_Safra;
    }

    public void setCodigo_Safra(int codigo_Safra) {
        Codigo_Safra = codigo_Safra;
    }
}
