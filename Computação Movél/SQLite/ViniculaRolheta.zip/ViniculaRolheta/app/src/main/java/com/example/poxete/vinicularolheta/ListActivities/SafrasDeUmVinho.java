package com.example.poxete.vinicularolheta.ListActivities;

import android.content.Context;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class SafrasDeUmVinho extends AppCompatActivity {
    int position;
    Context context = this;
    ArrayList<String> VINHOS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safras_de_um_vinho);
        setTitle("Escolha um vinho");

        inicializaSpinnerVinhos();

    }
    private void inicializaSpinnerVinhos() {
        VINHOS = carregaVinhos();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,VINHOS);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerSafrasDeUmVinho);
        spinner.setAdapter(adapter);


    }

    private ArrayList<String> carregaVinhos() {
        return DatabaseController.getInstance(this).buscarVinhoSpinner();
    }

    void att(View v){
        Spinner spinner = (Spinner) findViewById(R.id.spinnerSafrasDeUmVinho);
        position = spinner.getSelectedItemPosition();
        TextView safras = (TextView) findViewById(R.id.textViewSafrasDeUmVinho);
        String result = DatabaseController.getInstance(context).safrasDeUmVinho(VINHOS.get(position).split(":")[1]);
        if(result.trim().isEmpty())
            result = "Sem safras para esse vinho.";
        safras.setText(result);
    }
}
