package com.example.poxete.vinicularolheta.ListActivities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.R;

import org.w3c.dom.Text;

public class AnosMaisProdutivos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anos_mais_produtivos);

        TextView tv = (TextView) findViewById(R.id.textViewanosmaisprodutivos);
        tv.setText(DatabaseController.getInstance(this).anomaisprodutivo());
    }


}
