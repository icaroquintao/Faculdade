package com.example.poxete.vinicularolheta.Classes;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Propriedade {

    private String Nome_Prp;
    private String Administrador;
    private String Endereço;
    private String Região_Terroir;
    private ArrayList<String> telefone;
    private ArrayList<String> email;



    public Propriedade(String Nome_Prp, String Administrador, String Endereço, String Região_Terroir, ArrayList<String> telefone, ArrayList<String> email) {
        this.Nome_Prp = Nome_Prp;
        this.Administrador = Administrador;
        this.Endereço = Endereço;
        this.Região_Terroir = Região_Terroir;
        this.telefone = telefone;
        this.email = email;
    }

    public String getNome_Prp() {
        return Nome_Prp;
    }
    public void setNome_Prp(String nome_Prp) {
        Nome_Prp = nome_Prp;
    }
    public String getAdministrador() {
        return Administrador;
    }
    public void setAdministrador(String administrador) {
        Administrador = administrador;
    }
    public String getEndereço() {
        return Endereço;
    }
    public void setEndereço(String endereço) {
        Endereço = endereço;
    }
    public String getRegião_Terroir() {
        return Região_Terroir;
    }
    public void setRegião_Terroir(String região_Terroir) {
        Região_Terroir = região_Terroir;
    }


    public ArrayList<String> getTelefone() {
        return telefone;
    }

    public void setTelefone(ArrayList<String> telefone) {
        this.telefone = telefone;
    }

    public ArrayList<String> getEmail() {
        return email;
    }

    public void setEmail(ArrayList<String> email) {
        this.email = email;
    }


}
