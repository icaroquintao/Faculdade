package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class AddVinhoActivity extends AppCompatActivity {
    ArrayList<Integer> newIdsForSafra = new ArrayList<>();
    private static final int RESULT_IMAGE_FROM_GALLERY = 1;
    Bitmap photo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vinho);
        setTitle("Cadastrar novo Vinho");
    }

    void confirm (View v){
        EditText nomeVinho = (EditText) findViewById(R.id.editTextNomeVinho);
        String texto = nomeVinho.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Nome do vinho não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            nomeVinho.requestFocus();
            return;
        }

        EditText classificacao = (EditText) findViewById(R.id.editTextClassificacaoVinho);
        texto = classificacao.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Classificação do vinho não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            classificacao.requestFocus();
            return;
        }

        EditText codigo = (EditText) findViewById(R.id.editTextCodigoVinho);
        texto = codigo.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Código do vinho não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            codigo.requestFocus();
            return;
        }

        adicionarVinho(nomeVinho.getText().toString(),
                        classificacao.getText().toString(),
                        Integer.parseInt(codigo.getText().toString()));
    }

    private void adicionarVinho(String nomeVinho,String classificacao,int codVinho) {//table vinho
        try{ContentValues values = new ContentValues();
        values.put("nomeVinho", nomeVinho);
        values.put("classificacao", classificacao);
        values.put("codVinho", codVinho);
        values.put("rotulo", (byte[]) null);

        DatabaseController.getInstance(this).db.insert("vinho","",values);}catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public void fromGallery(View view) {
        Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
        gallery.setType("image/*");
        startActivityForResult(gallery, RESULT_IMAGE_FROM_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == RESULT_IMAGE_FROM_GALLERY) {
            Uri imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                bitmap = getResizedSquareBitmap(bitmap);
                bitmap = getResizedBitmap(bitmap, IMAGE_SIZE);
                bitmap = getCroppedBitmap(bitmap);
                ImageView imageView = (ImageView) findViewById(R.id.imageView);
                imageView.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if(resultCode == RESULT_OK && requestCode == RESULT_IMAGE_FROM_CAMERA) {
            Bundle extras = data.getExtras();
            Bitmap bitmap = (Bitmap) extras.get("data");
            bitmap = getResizedSquareBitmap(bitmap);
            bitmap = getResizedBitmap(bitmap, IMAGE_SIZE);
            bitmap = getCroppedBitmap(bitmap);
            ImageView imageView = (ImageView) findViewById(R.id.imageView);
            imageView.setImageBitmap(bitmap);
        } else if(resultCode == RESULT_OK && requestCode == RESULT_IMAGE_FROM_CONTACT) {
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                dialogPhotoOptions.dismiss();
                return;
            }

            //Permission granted
            Uri contactUri = data.getData();
            String contactID = "";
            // getting contacts ID
            Cursor cursorID = getContentResolver().query(contactUri,
                    new String[]{ContactsContract.Contacts._ID},
                    null, null, null);

            if (cursorID.moveToFirst()) {

                contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID));
            }
            cursorID.close();

            Log.d("CSI489", "Contact ID: " + contactID);

            //Get contact info and do required changes
            String contactName = getContactName(contactUri);
            String contactNumber = getContactNumber(contactID);
            EditText et = (EditText) findViewById(R.id.nameAdd);
            et.setText(contactName);
            EditText et2 = (EditText) findViewById(R.id.phoneAdd);
            et2.setText(contactNumber);

            Bitmap bitmap = getContactPhoto(contactID);
            if(bitmap != null) {
                bitmap = getResizedSquareBitmap(bitmap);
                bitmap = getResizedBitmap(bitmap, IMAGE_SIZE);
                bitmap = getCroppedBitmap(bitmap);
                ImageView imageView = (ImageView) findViewById(R.id.imageView);
                imageView.setImageBitmap(bitmap);

            }
        }
        dialogPhotoOptions.dismiss();
    }



}
