package com.example.poxete.vinicularolheta.Classes;

import android.graphics.Bitmap;

/**
 * Created by Poxete on 20/08/2017.
 */

public class Vinho {
    private String Nome;
    private String Classificação;
    private Bitmap rótulo;
    private int Cod_Vinho;

    public Vinho(String Nome, String Classificação, int Cod_Vinho){
        this.Classificação = Classificação;
        this.Nome = Nome;
        this.Cod_Vinho = Cod_Vinho;
    }

    public Bitmap getRótulo() {
        return rótulo;
    }

    public void setRótulo(Bitmap rótulo) {
        this.rótulo = rótulo;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getClassificação() {
        return Classificação;
    }

    public void setClassificação(String classificação) {
        Classificação = classificação;
    }

    public int getCod_Vinho() {
        return Cod_Vinho;
    }

    public void setCod_Vinho(int cod_Vinho) {
        Cod_Vinho = cod_Vinho;
    }

}
