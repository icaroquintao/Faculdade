package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddParreiralActivity extends AppCompatActivity {
    ArrayList<String> PROPRIEDADES;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parreiral);
        setTitle("Adicionar Novo Parreiral");
        inicializaSpinnerPropriedade();
    }

    private void inicializaSpinnerPropriedade() {
        PROPRIEDADES = carregaPropriedades();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,PROPRIEDADES);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddParreiral);
        spinner.setAdapter(adapter);
    }

    private ArrayList<String> carregaPropriedades() {
        return DatabaseController.getInstance(this).buscarPropriedades();
    }

    void confirm (View v){
        EditText qtdVinhas = (EditText) findViewById(R.id.editTextQntdVinhas);
        String texto = qtdVinhas.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Quantidade de vinhas não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            qtdVinhas.requestFocus();
            return;
        }

        EditText area = (EditText) findViewById(R.id.editTextArea);
        texto = area.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Área do parreiral não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            area.requestFocus();
            return;
        }

        EditText codigoparreiral = (EditText) findViewById(R.id.editTextCodigoparreiral);
        texto = codigoparreiral.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Código do parreiral não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            codigoparreiral.requestFocus();
            return;
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddParreiral);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Propriedade não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }

        DatePicker date = (DatePicker) findViewById(R.id.datePickerDataPlantio);
        int dia = date.getDayOfMonth();
        int mes = date.getMonth();
        int ano = date.getYear();
        ano-=1900;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        adicionaParreiral(Integer.parseInt(codigoparreiral.getText().toString()),
                Integer.parseInt(qtdVinhas.getText().toString()),
                Float.parseFloat(area.getText().toString()),
                sdf.format(new Date(ano,mes,dia)),
                PROPRIEDADES.get(spinner.getSelectedItemPosition()));
    }

    private void adicionaParreiral(int codigo, int quantidade, float area,String dataplantio,String NomePropriedade){
        try{ContentValues valuesprp = new ContentValues();
        valuesprp.put("codParreiral", codigo);
        valuesprp.put("qntdVinhas", quantidade);
        valuesprp.put("area", area);
        valuesprp.put("data_Plantio", dataplantio);
        valuesprp.put("NomePropriedade",NomePropriedade);
        DatabaseController.getInstance(this).db.insert("parreiral", "", valuesprp);}catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
        Intent i=new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}
