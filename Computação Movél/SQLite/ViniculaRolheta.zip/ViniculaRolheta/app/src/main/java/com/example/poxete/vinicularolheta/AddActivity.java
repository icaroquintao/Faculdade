package com.example.poxete.vinicularolheta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.poxete.vinicularolheta.AddActivities.AddAvaliacaoActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddColheitaActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddParreiralActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddPropriedadeActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddSafraActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddTerroirActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddTipoDeUvaActivity;
import com.example.poxete.vinicularolheta.AddActivities.AddVinhoActivity;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }


    void addParreiral(View v){
        Intent it = new Intent(this, AddParreiralActivity.class);
        startActivity(it);
    }

    void addTerroir(View v){
        Intent it = new Intent (this, AddTerroirActivity.class);
        startActivity(it);
    }

    void addPropriedade(View v){
        Intent it = new Intent(this,AddPropriedadeActivity.class);
        startActivity(it);
    }

    void addVinho(View v){
        Intent it = new Intent(this, AddVinhoActivity.class);
        startActivity(it);
    }
    void addColheita(View v){
        Intent it = new Intent(this, AddColheitaActivity.class);
        startActivity(it);
    }
    void addSafra(View v){
        Intent it = new Intent(this, AddSafraActivity.class);
        startActivity(it);
    }
    void addTipodeuva(View v){
        Intent it = new Intent(this, AddTipoDeUvaActivity.class);
        startActivity(it);
    }
    void addAvaliacao(View v){
        Intent it = new Intent (this, AddAvaliacaoActivity.class);
        startActivity(it);
    }
}
