package com.example.poxete.vinicularolheta.AddActivities;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.Layout;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poxete.vinicularolheta.DBManager.DatabaseController;
import com.example.poxete.vinicularolheta.MainActivity;
import com.example.poxete.vinicularolheta.R;

import java.util.ArrayList;

public class AddPropriedadeActivity extends AppCompatActivity {
    private ArrayList<Integer> newIdsForEmail = new ArrayList<>();
    private ArrayList<Integer> newIdsForTel = new ArrayList<>();
    private ArrayList<String> REGIAOTERROIR;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_propriedade);
        setTitle("Adicionar Nova Propriedade");
        inicializaSpinnerRegiao();

    }

    private void inicializaSpinnerRegiao() {
        REGIAOTERROIR = carregaTerroir();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,REGIAOTERROIR);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddPropriedade);
        spinner.setAdapter(adapter);

    }

    ArrayList<String> carregaTerroir(){
        return DatabaseController.getInstance(this).buscarRegiaoTerroirSpinner();
    }

    void confirm(View v){
        EditText nomeprp = (EditText) findViewById(R.id.editTextNomePrp);
        String texto = nomeprp.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Nome da propriedade não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            nomeprp.requestFocus();
            return;
        }

        EditText endereco = (EditText) findViewById(R.id.editTextEndereco);
        texto = endereco.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Endereço não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            endereco.requestFocus();
            return;
        }

        EditText administrador = (EditText) findViewById(R.id.editTextAdministrador);
        texto = administrador.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Administrador não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            administrador.requestFocus();
            return;
        }

        EditText email = (EditText) findViewById(R.id.editTextEmail);
        texto = email.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Deve ser digitado pelo menos 1 email.",Toast.LENGTH_SHORT).show();
            email.requestFocus();
            return;
        }

        EditText tel = (EditText) findViewById(R.id.editTextTel);
        texto = tel.getText().toString();
        if (texto.trim().isEmpty())
        {
            Toast.makeText(this,"Deve ser digitado pelo menos 1 telefone.",Toast.LENGTH_SHORT).show();
            tel.requestFocus();
            return;
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinnerAddPropriedade);
        if(spinner.getSelectedItem() == null)
        {
            Toast.makeText(this,"Região não pode ser um campo vazio.",Toast.LENGTH_SHORT).show();
            spinner.requestFocus();
            return;
        }
        adicionaPropriedade(nomeprp.getText().toString(),
                endereco.getText().toString(),
                administrador.getText().toString(),
                REGIAOTERROIR.get(spinner.getSelectedItemPosition()),
                tel.getText().toString(),
                email.getText().toString());
    }

    void adicionaPropriedade(String nomeprp,String endereco,String adm, String regiao,String tel,String email){
        try {
            ContentValues valuesprp = new ContentValues();
            valuesprp.put("NomePropriedade", nomeprp);
            valuesprp.put("Endereco", endereco);
            valuesprp.put("Administrador", adm);
            valuesprp.put("RegiaoTerroir", regiao);
            DatabaseController.getInstance(this).db.insert("propriedade", "", valuesprp);


            ContentValues valuesTel = new ContentValues();
            valuesTel.put("NomePropriedade",nomeprp);
            valuesTel.put("telefone",tel);
            DatabaseController.getInstance(this).db.insert("telefone", "", valuesTel);

            for(Integer i: newIdsForTel)
            {
                valuesTel = new ContentValues();
                valuesTel.put("NomePropriedade",nomeprp);
                EditText phone = (EditText) findViewById(i);
                valuesTel.put("telefone",phone.getText().toString());
                DatabaseController.getInstance(this).db.insert("telefone", "", valuesTel);
            }

            ContentValues valuesemail = new ContentValues();
            valuesemail.put("NomePropriedade",nomeprp);
            valuesemail.put("email",email);
            DatabaseController.getInstance(this).db.insert("email", "", valuesemail);

            for(Integer i: newIdsForEmail)
            {
                valuesemail = new ContentValues();
                valuesemail.put("NomePropriedade",nomeprp);
                EditText mail = (EditText) findViewById(i);
                valuesemail.put("email",mail.getText().toString());
                DatabaseController.getInstance(this).db.insert("email", "", valuesTel);
            }

            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"Não foi possível inserir no banco de dados.",Toast.LENGTH_SHORT).show();
        }
    }


    void createNewEditTextForEmail(View v){
        LinearLayout texts = (LinearLayout) findViewById(R.id.linearLayoutEmails);
        Space space = new Space(AddPropriedadeActivity.this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1,20));
        texts.addView(space);
        EditText text = new EditText(AddPropriedadeActivity.this);
        text.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT));
        text.setEms(10);
        text.setText("");
        text.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        int aux = View.generateViewId();
        text.setId(aux);
        newIdsForEmail.add(aux);
        text.setBackgroundColor(0x66FFFFFF);
        texts.addView(text);
        text.requestFocus();

    }
    void createNewEditTextForTel(View v){
        LinearLayout texts = (LinearLayout) findViewById(R.id.linearLayoutTels);
        Space space = new Space(AddPropriedadeActivity.this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1,20));
        texts.addView(space);
        EditText text = new EditText(AddPropriedadeActivity.this);
        text.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT));
        text.setEms(10);
        text.setText("");
        text.setInputType(InputType.TYPE_CLASS_PHONE);
        int aux = View.generateViewId();
        text.setId(aux);
        newIdsForTel.add(aux);
        text.setBackgroundColor(0x66FFFFFF);
        texts.addView(text);
        text.requestFocus();

    }
}
