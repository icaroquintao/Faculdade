package com.example.poxete.vinicularolheta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.poxete.vinicularolheta.ListActivities.AnosMaisProdutivos;
import com.example.poxete.vinicularolheta.ListActivities.ListPropriedades;
import com.example.poxete.vinicularolheta.ListActivities.ListarVinhosActivity;
import com.example.poxete.vinicularolheta.ListActivities.SafrasDeUmVinho;
import com.example.poxete.vinicularolheta.ListActivities.TiposDeUvaPropriedade;

public class ListMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_menu);
        setTitle("Selecione o relatório desejado");
    }
    public void vinhosproduzidos(View v){
        Intent it = new Intent(this, ListarVinhosActivity.class);
        startActivity(it);
    }

    public void safrasDeUmVinho(View v){
        Intent it = new Intent(this, SafrasDeUmVinho.class);
        startActivity(it);
    }

    public void listPropriedades (View v){
        Intent it = new Intent (this, ListPropriedades.class);
        startActivity(it);
    }
    public void tiposuvapropriedade(View v){
        Intent it = new Intent (this, TiposDeUvaPropriedade.class);
        startActivity(it);
    }
    public void anosprodutivos (View v){
        Intent it = new Intent (this, AnosMaisProdutivos.class);
        startActivity(it);
    }

}
