package com.example.poxete.vinicularolheta.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.poxete.vinicularolheta.Classes.Safra;
import com.example.poxete.vinicularolheta.R;

import java.util.List;

/**
 * Created by Poxete on 20/08/2017.
 */

public class SafraAdapter extends BaseAdapter {

    private Context context;
    private List<Safra> list;

    public SafraAdapter(Context context, List<Safra> list) {
        this.context = context;
        this.list = list;
    }

    public int getCount() {
        return list.size();
    }

    public Object getItem(int position) {
        Safra safra = list.get(position);
        return safra;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        //Recovers the Player in the current position

        Safra safra= list.get(position);

        //Creates a View object from the given XML layout
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.safra_adpter, null);

        //Updates TextView’s text to the Student’s info
        TextView textCdg = (TextView) v.findViewById(R.id.cdg);//codigo da safra
        textCdg.setText(safra.getCod_Safra());
        TextView textAnoSafra = (TextView) v.findViewById(R.id.as);//ano da safra
        textAnoSafra.setText(safra.getAno_Safra());


        return v;
    }
}
